const movies = [
  {title:"Echo Valley", year:"2026", rating:"4.3", cls:"m1"},
  {title:"The Orbit", year:"2026", rating:"4.7", cls:"m2"},
  {title:"Blue Horizon", year:"2025", rating:"4.1", cls:"m3"},
  {title:"Silent River", year:"2026", rating:"3.9", cls:"m4"},
  {title:"Northbound", year:"2026", rating:"4.5", cls:"m5"}
];

const grid = document.getElementById("movieGrid");
function renderMovies(list=movies){
  grid.innerHTML = list.map(m => `
    <article class="movie-card" onclick="openMovie('${m.title}')">
      <div class="movie-poster ${m.cls}">${m.title.toUpperCase()}</div>
      <div class="movie-info"><strong>${m.title}</strong><span>${m.year} · Drama</span><div class="rating">★ ${m.rating}</div></div>
    </article>`).join("");
}
renderMovies();

function scrollToSection(id){document.getElementById(id).scrollIntoView({behavior:"smooth"});}
function openLogModal(){document.getElementById("logModal").classList.remove("hidden");}
function closeLogModal(){document.getElementById("logModal").classList.add("hidden");}
function saveFilm(){
  const title=document.getElementById("filmTitle").value.trim();
  if(!title){alert("Please enter a film title.");return;}
  const count=document.getElementById("watchedCount");
  count.textContent=Number(count.textContent)+1;
  alert(`${title} was added to your diary.`);
  document.getElementById("filmTitle").value="";
  document.getElementById("filmReview").value="";
  closeLogModal();
}
function toggleLike(btn){btn.classList.toggle("liked");btn.textContent=btn.classList.contains("liked")?"♥":"♡";}
function removeWatch(btn){
  btn.closest(".watch-item").remove();
  const pill=document.getElementById("watchCount");
  pill.textContent=Math.max(0,Number(pill.textContent)-1);
}
function openMovie(title){alert(`${title}\\n\\nFilm details, reviews, rating and watchlist controls would open here.`);}
function filterFilms(){renderMovies([...movies].reverse());}
function openSearch(){document.getElementById("searchDrawer").classList.remove("hidden");document.getElementById("searchInput").focus();}
function closeSearch(){document.getElementById("searchDrawer").classList.add("hidden");}
document.getElementById("searchBtn").addEventListener("click",openSearch);
function searchMovies(){
  const q=document.getElementById("searchInput").value.toLowerCase().trim();
  const results=document.getElementById("searchResults");
  const found=movies.filter(m=>m.title.toLowerCase().includes(q));
  results.innerHTML=q ? (found.length ? found.map(m=>`<div class="result"><strong>${m.title}</strong> · ${m.year} · ★ ${m.rating}</div>`).join("") : `<div class="result">No films found.</div>`) : "";
}
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeSearch();closeLogModal();}});
