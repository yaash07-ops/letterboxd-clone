# FilmLog — Social Film Diary UI Template

## Assignment
UI Template Collection Hackathon / GitHub Team Collaboration

## UI Topic
Social Film Discovery / Movie Diary

## About
FilmLog is an original student-built frontend UI inspired by modern social film diary patterns. It is not an official Letterboxd clone and does not use Letterboxd source code or branding assets.

The design focuses on discovering films, keeping a watchlist, recording diary entries, rating films, and browsing curated lists.

These patterns are based on the documented functionality of social film diary services: film logging, ratings, reviews, watchlists, lists, profiles and activity feeds.

## Features
- Responsive landing page
- Film discovery cards
- Diary / recent activity section
- Watchlist interaction
- Like buttons
- Log-a-film modal
- Search drawer
- Film statistics
- Curated film lists
- Mobile responsive layout

## Technologies
- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts

## Folder Structure
```text
letterboxd-ui/
├── index.html
├── style.css
├── script.js
└── README.md
```

## How to Run
1. Extract the ZIP.
2. Open the project folder.
3. Double-click `index.html`.
4. The UI runs in a modern browser.

No backend or installation is required.

## Research Notes
The selected UI pattern is a social film diary. Common interactions include:
- Recording watched films
- Rating films
- Writing reviews
- Maintaining a watchlist
- Creating film lists
- Following activity from other members
- Searching for films and people

## Originality
This project is an original educational implementation. It uses a different project name, layout, styling and placeholder visual treatment rather than copying the Letterboxd website.

## Suggested Git Branch
`member1-film-diary`

## Suggested Commit
`Add responsive social film diary UI`

## Suggested Pull Request
Title: `Add Film Diary UI Template`

Description:
- Added responsive film diary interface
- Added movie discovery cards
- Added diary and watchlist interactions
- Added search and log-film modal
- Added project documentation

## Credits / Research
Letterboxd official documentation was consulted for understanding the general UI pattern:
- https://letterboxd.com/home/
- https://letterboxd.com/welcome/

Do not use Letterboxd trademarks, logos or copyrighted artwork in the final academic project unless your institution has permission.
